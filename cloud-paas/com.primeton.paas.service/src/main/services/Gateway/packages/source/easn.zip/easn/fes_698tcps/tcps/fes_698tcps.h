#ifndef FES_698TCPS_H_
#define FES_698TCPS_H_
#include <stdlib.h>
#include "net/anet.h"
#include "net/adlist.h"
#include "net/ae.h"
#include "net/sds.h"
#include "netinet/in.h"
#include <errno.h>
#include <signal.h>
#include <string.h>

/* Anti-warning macro... */
#define FES_NOTUSED(V) ((void) V)

#define FES_REPLY_CHUNK_BYTES  (16*1024) /* 16k output buffer */
#define FES_IOBUF_LEN          (16*1024) /* 16k output buffer */

#define MASTER_FES_REPLY_CHUNK_BYTES  (32*1024) /* 32k output buffer */
#define MASTER_FES_IOBUF_LEN          (32*1024) /* 32k output buffer */

#define MAX_MASTER_REPLY		 10000000
#define MAX_MASTER               20
#define MAX_RECORD_BUFFER        10*1024*1024
#define MAX_RECORD_INVALID_BUFFER        10*1024*1024
//#define MAX_TIME_INTERVAL		 15*60
#define MAX_TIME_INTERVAL		 1*60

typedef struct RecordBuffer{
	char buf[MAX_RECORD_BUFFER];
	int bufpos;
}RecordBuffer;

typedef struct MasterAddress {
	char masterIP[25];
	int port;
	int bind;
        char msa;
}MasterAddress;

typedef struct Fes698TcpsClient {
	int fd;
	unsigned char protype;//协议类型
	time_t ctime; /* Client creation time */
	time_t lastinteraction; /* time of the last interaction, used for timeout */
	int flags; /* FES_SLAVE | FES_MONITOR | ... */
	list *reply;
	unsigned long receive_bytes; /* Tot bytes of objects in reply list */
	unsigned long reply_bytes; /* Tot bytes of objects in reply list */
	int bufpos;
	struct sockaddr_in remote;
	struct sockaddr_in local;
	char buf[FES_REPLY_CHUNK_BYTES];
	char readbuf[FES_REPLY_CHUNK_BYTES];
	int readbufpos;
	int sentlen;
	int masterfd;//绑定的前置句柄号
	time_t bindtime; /* Client Master bind time */
} Fes698TcpsClient;

typedef struct Fes698TcpsMaster {
	int fd;
	time_t ctime; /* Client creation time */
	time_t lastinteraction; /* time of the last interaction, used for timeout */
	int flags; /* FES_SLAVE | FES_MONITOR | ... */
	list *reply;
	unsigned long receive_bytes; /* Tot bytes of objects in reply list */
	unsigned long reply_bytes; /* Tot bytes of objects in reply list */
	int bufpos;
	struct sockaddr_in remote;
	struct sockaddr_in local;
	char buf[MASTER_FES_REPLY_CHUNK_BYTES];
	char readbuf[MASTER_FES_REPLY_CHUNK_BYTES];
	int readbufpos;
	int sentlen;
	int open;//0关闭1打开
	int bind;//0不绑定，1绑定
} Fes698TcpsMaster;

typedef struct Fes698TcpsServer {
	aeEventLoop *el;
	char *pidfile; /* PID file path */
	int port; /* TCP listening port */
	char *bindaddr; /* Bind address or NULL */
	int ipfd; /* TCP socket file descriptor */
	list *clients; /* List of active clients */
	list *clients_to_close; /* Clients to close asynchronously */
	list *monitors; /* List of slaves and MONITORs */
	unsigned int maxclients; /* Max number of simultaneous clients */
	unsigned long long maxmemory; /* Max number of memory bytes to use */
	time_t unixtime;
	char neterr[ANET_ERR_LEN]; /* Error buffer for anet.c */
	int maxidletime; /* Client timeout in seconds */
	int maxbindtime; /* Client Master bind timeout in seconds */
	int tcpkeepalive; /* Set SO_KEEPALIVE if non-zero. */
	int mastertcpkeepalive;
	int daemonize; /* True if running as a daemon */
	char *logfile; /* Path of log file */
	int stat_numconnections;
	int stat_rejected_conn;
	int shutdown;
	Fes698TcpsClient *current_client;
	Fes698TcpsMaster *master[MAX_MASTER];//和主站通讯
//	Fes698TcpsMaster *current_master;
	char transmissionQueueName[32];
	char analystQueueName[32];
} Fes698TcpsServer;
Fes698TcpsClient   *getActiveClient(int fd);

int writeDataToClient(Fes698TcpsClient *c, char *buf,int length);
int processDataFrame(Fes698TcpsClient *c,char *frameHead,int frameSize);

int addToWriteBuffer(int fd, char *buf,int length);
int addToMasterWriteBuffer(int fd, char *buf, int length);
int addToMasterWriteBufferEx(char *buf, int length);
void freeClient(Fes698TcpsClient *c, int type);

void recordData(char *data, int len);
void recordInvalidData(Fes698TcpsClient *c, char *data, int len );

int tpcsDispatchIpc();


void setGatewayNum(char num);
char getGatewayNum();
int getMasterCount();
int getBindMasterCount();
char getDoPing();
#endif /*FES_698TCPS_H_*/
