#ifndef FES_698_COMM_H_
#define FES_698_COMM_H_

#include <netinet/in.h>
#include <stdint.h>
#include "tcps/fes_698tcps.h"
#include "util/util.h"

#define HEAD_SIGN           0xA8
#define MIN_MASTER_MSG_SIZE (1+2+1+1+23)  //网关和前置机通讯报文最短长度

#define ADDTYPE_IPV4        0



#define CTRL_SEND           0x1//发送数据
#define CTRL_CLOSE          0x2//连接关闭,终端断开连接，网关通知前置机连接断开
#define CTRL_RESET          0x3//网关复位
#define CTRL_CLOSE_DOMN		0x4//前置下发关闭终端连接
#define CTRL_CLOSE_BIND		0x5//前置下发终端绑定
#define CTRL_CLOSE_UNBIND	0x6//前置下发终端解绑
#define CTRL_FAIL			0xFF//前置发送给终端报文，地址不合法

#pragma pack(1)
//地址域
typedef struct AddressFmt{
	uint8_t gatewayNum;//网关编号
	uint32_t ipv6a;//IP地址
	uint32_t ipv6b;//IP地址
	uint32_t ipv6c;//IP地址
	uint32_t ipv6d;//IP地址v4
	uint16_t port;//端口号
	uint32_t fd;//连接ID（句柄编号）
}AddressFmt;

//网关和前置机通讯报文
typedef struct MasterMessage{
	uint8_t head; //起始字符
	uint16_t length; //长度
	uint8_t ctrl; //控制命令
	uint8_t dataType;//数据类型域
	AddressFmt addressFmt;//地址格式
	uint8_t data[0];
} MasterMessage;

#pragma pack()

int writeToNextProc(Fes698TcpsClient *c, const char *buf, const int length);
int writeToMasterNextProc(Fes698TcpsMaster *m, const char *buf, const int length);
int writeToMasterGWResetMsg(Fes698TcpsMaster *m);
int writeToMasterConnCloseMsg(Fes698TcpsClient *c, int type);
#endif
