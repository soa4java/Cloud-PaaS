#include "protocolmanager.h"
#include "comm/heart.h"

static ProtocolModule proModules[2];

ProtocolModule *getProtocolModuleByProType(int protype){
  int i;
  for(i=0; i<ELEMENTS_COUNT(proModules); i++){
    if((proModules+i)->proType == protype)
      return proModules+i;
  }
  return NULL;
}

#if 0
ProtocolModule *getProtocolModuleByData(uint8_t *data){
  int i;
  for(i=0; i<ELEMENTS_COUNT(proModules); i++){
    if((proModules+i)->check(data) > 0)
      return proModules+i;
  }
  return NULL;
}

int check_3761(uint8_t * data) {
  uint8_t *buff = data;
  int length = 0;
  int matchResult = -1;

  if ((buff[0] == 0x68) && (buff[5] == 0x68)) {
    if ((buff[1] == buff[3]) && (buff[2] == buff[4])) {
      length = (((buff[2]&0xFF)<<8) + (buff[1]&0xFF)) >> 2;
      if (buff[6+length+1] == 0x16){
        //只要符合格式就认为是3761，不判断长度域中的一字节的标志 20140613
        //			if ((buff[6+length+1] == 0x16) && ((buff[1] & 0x3) == 0x2)) {
        matchResult = 1;
      }
    }
  }
  return matchResult;
}

int check_04(uint8_t * data) {
  uint8_t *buff = data;
  int length = 0;
  int matchResult = -1;

  if ((buff[0] == 0x68) && (buff[5] == 0x68)) {
    if ((buff[1] == buff[3]) && (buff[2] == buff[4])) {
      length = (((buff[2]&0xFF)<<8) + (buff[1]&0xFF)) >> 2;
      if ((buff[6+length+1] == 0x16) && ((buff[1] & 0x3) == 0x1)) {
        matchResult = 1;
      }
    }
  }
  return matchResult;
}
#endif

ProtocolModule *getProtocolModuleByData(Fes698TcpsClient *c)
{
  int i;
  for(i=0; i<ELEMENTS_COUNT(proModules); i++){
    if((proModules+i)->check(c) > 0)
      return proModules+i;
  }
  return NULL;
}

int check_3761(Fes698TcpsClient *c) {
  int bufSize = c->readbufpos;
  uint8_t *buff = (uint8_t *)c->readbuf;
  int i;
  int length = 0;
  int matchResult = -1;

  for(i = 0; i + 5 < bufSize; i ++){
    if ((buff[i + 0] == 0x68) && (buff[i + 5] == 0x68)
        && (buff[i + 1] == buff[i + 3]) && (buff[i + 2] == buff[i + 4])) {
      length = (((buff[i + 2]&0xFF)<<8) + (buff[i + 1]&0xFF)) >> 2;
      if (i + 6 + length + 1 < bufSize) {
        if (buff[i + 6 + length + 1] == 0x16){
          matchResult = 1;
        }
      } else {
        break;
      }
    }
  }

  return matchResult;
}

int check_04(Fes698TcpsClient *c) {
  int bufSize = c->readbufpos;
  uint8_t *buff = (uint8_t *)c->readbuf;
  int i;
  int length = 0;
  int matchResult = -1;

  for(i = 0; i + 5 < bufSize; i ++){
    if ((buff[i+0] == 0x68) && (buff[i+5] == 0x68)) {
      if ((buff[i+1] == buff[i+3]) && (buff[i+2] == buff[i+4])) {
        length = (((buff[i+2] & 0xFF) << 8) + (buff[i+1] & 0xFF)) >> 2;
        if ((buff[i+6 + length + 1] == 0x16) && ((buff[i+1] & 0x3) == 0x1)) {
          matchResult = 1;
        }
      }
    }
  }
  return matchResult;
}

#define true  1
#define false 0
#define BLOCK_START_SIGN  0x68
#define BLOCK_END_SIGN    0x16

int doping_3761(Fes698TcpsClient *c, char *buff, int length){
  return heartProcessFunc(c, buff, length);
}

int doping_04(Fes698TcpsClient *c, char *buff, int length){
  return heartProcessFunc(c, buff, length);
}

typedef struct pack_pos {
  unsigned int head;
  unsigned int tail;
} pack_pos_t;

typedef struct pack_pos_info {
  unsigned int size;
  unsigned int used;
  pack_pos_t *pack_pos;
} pack_pos_info_t;

#define PACK_POS_INFO_INIT_SIZE 64
#define PACK_POS_INFO_INCR_SIZE 16

pack_pos_info_t *pack_pos_info_init(void);
void pack_pos_info_cleanup(pack_pos_info_t *pack_pos_info);
int pack_pos_info_record(pack_pos_info_t *pack_pos_info, unsigned int head, unsigned int tail);
int pack_log(Fes698TcpsClient *c, unsigned char *data, unsigned int len, pack_pos_info_t *pack_pos_info);

int unpack_3761(Fes698TcpsClient *c) {
  int bufSize = c->readbufpos;
  int startPosition = 0;
  int findHead, i;
  int frameCount = 0;
  char * head = (char *) c->readbuf;
  int enough = true;
  pack_pos_info_t *pack_pos_info;

  pack_pos_info = pack_pos_info_init();
  while (true) {
    if ((bufSize - startPosition < 8))
      enough = false;
    findHead = false;
    if (!enough) {
      int leftBufSize = bufSize - startPosition;
      pack_log(c, head, startPosition, pack_pos_info);
      pack_pos_info_cleanup(pack_pos_info);

      if (leftBufSize > 0)
        memcpy(head, head + startPosition, leftBufSize);
      c->readbufpos = leftBufSize;
      return frameCount;
    }
    for (i = startPosition; i < bufSize - 8; i++) {
      if ((head[i] == BLOCK_START_SIGN)
          && (head[i + 5] == BLOCK_START_SIGN)) {
        findHead = true;
        int len = ((head[i + 1] & 0xff)
            + (((int) (head[i + 2] & 0xff)) << 8)) >> 2;
        int packageSize = len + 8;
        if (bufSize < i + packageSize) {
          enough = false;
          break;
        }
        if (head[packageSize + i - 1] == BLOCK_END_SIGN) {
          //获得完整的一帧报文，记录缓存
          recordData(head + i, packageSize);
          pack_pos_info_record(pack_pos_info, i, i + packageSize - 1);
          //printf("up:");
          //printHexCode(head + i, packageSize);
          //20140724，如果有doping，就执行
          if ((getDoPing() > 0) && (doping_3761(c, head + i, packageSize) != 1))
            processDataFrame(c, head + i, packageSize);
          else
            processDataFrame(c, head + i, packageSize);
          //	writeDataToClient(c,head+i,packageSize);
          ++frameCount;
          startPosition = i + packageSize;
          break;
        } else {
          startPosition = i + 1;
          break;
        }
      }
    }
    if (!findHead) {
      startPosition = bufSize - 8 + 1;
    }
  }
  printf("\n[%d]How could you reach here ...\n", frameCount);
  return frameCount;
}

int unpack_04(Fes698TcpsClient *c){
  return unpack_3761(c);
}


int unpackFrame(Fes698TcpsClient *c){
  ProtocolModule *pm;
  if(c->protype > 0){
    pm = getProtocolModuleByProType(c->protype);
    if (pm != NULL)
      return pm->unpack(c);
  } else {
    //pm = getProtocolModuleByData((uint8_t *)c->readbuf);
    pm = getProtocolModuleByData(c);
    char address[32] = {0};
    sprintf(address, "%d.%d.%d.%d:%d#%d", c->remote.sin_addr.s_addr & 0xFF,
        (c->remote.sin_addr.s_addr >> 8) & 0xFF,
        (c->remote.sin_addr.s_addr >> 16) & 0xFF,
        (c->remote.sin_addr.s_addr >> 24) & 0xFF,
        ntohs(c->remote.sin_port),c->fd);
    if (pm != NULL){
      printTime();
      printf("%s,unpack success......\n", address);
      c->protype = pm->proType;
      unpackFrame(c);
    } else {
      printTime();
      printf("%s,unpack error......\n", address);
    }
  }
  return 0;
}

int dopingFrame(Fes698TcpsClient *c, uint8_t *data, int length){
  return 0;
}

void initProtocolManager(){
  memset(proModules, 0, sizeof(proModules));
  //注册3761
  proModules[0].proType = PROTYPE_3761;
  proModules[0].check = check_3761;
  proModules[0].unpack = unpack_3761;
  proModules[0].doping = doping_3761;
  //注册电力负荷管理系统数据传输规约-2004
  proModules[1].proType = PROTYPE_04;
  proModules[1].check = check_04;
  proModules[1].unpack = unpack_04;
  proModules[1].doping = doping_04;
}

pack_pos_info_t *pack_pos_info_init(void)
{
  pack_pos_info_t *pack_pos_info;

  pack_pos_info = (pack_pos_info_t *)malloc(sizeof(pack_pos_info_t));
  if(pack_pos_info){
    pack_pos_info->pack_pos = (pack_pos_t*)malloc(sizeof(pack_pos_t) * PACK_POS_INFO_INIT_SIZE);
    if(!(pack_pos_info->pack_pos)){
      free(pack_pos_info);
      return NULL;
    }
    pack_pos_info->size = PACK_POS_INFO_INIT_SIZE;
    pack_pos_info->used = 0;
  }

  return pack_pos_info;
}

void pack_pos_info_cleanup(pack_pos_info_t *pack_pos_info)
{
  if(pack_pos_info){
    if(pack_pos_info->pack_pos)
      free(pack_pos_info->pack_pos);
    free(pack_pos_info);
  }
}

int pack_pos_info_record(pack_pos_info_t *pack_pos_info, unsigned int head, unsigned int tail)
{
  pack_pos_t *pack_pos_new;
  unsigned int size_new;

  if((!pack_pos_info) || tail <= head)
    return -1;

  if(pack_pos_info->used >= pack_pos_info->size){
    size_new = pack_pos_info->size + PACK_POS_INFO_INCR_SIZE;
    pack_pos_new = realloc(pack_pos_info->pack_pos, sizeof(pack_pos_t) * size_new);
    if(!pack_pos_new)
      return -1;
    pack_pos_info->pack_pos = pack_pos_new;
    pack_pos_info->size = size_new;
  }

  pack_pos_info->pack_pos[pack_pos_info->used].head = head;
  pack_pos_info->pack_pos[pack_pos_info->used].tail = tail;
  pack_pos_info->used ++;
  return 0;
}

int pack_log(Fes698TcpsClient *c, unsigned char *data, unsigned int len, pack_pos_info_t *pack_pos_info)
{
  char *log_buf, *log_data;
  unsigned int log_buf_len, i;

  if((!c) || (!data) || 0 == len)
    return -1;

  log_buf_len = 2 + len * 3;
  log_buf = (char *)malloc(log_buf_len);
  if(!log_buf)
    return -1; 
  log_buf[0] = '\n';
  log_buf[1] = ' ';
  log_data = log_buf + 2;

  for(i = 0; i < len; i ++){
    snprintf(log_data + i * 3, 3, "%02x ", data[i]);
    *(log_data + i * 3 + 2) = ' ';
  }

  if(pack_pos_info){
    for(i = 0; i < pack_pos_info->used; i ++){
      if(pack_pos_info->pack_pos[i].head < pack_pos_info->pack_pos[i].tail
          && pack_pos_info->pack_pos[i].tail < log_buf_len){
        *(log_data + pack_pos_info->pack_pos[i].head * 3 - 1) = '\n';
        *(log_data + pack_pos_info->pack_pos[i].head * 3) = '[';
        *(log_data + pack_pos_info->pack_pos[i].tail * 3 + 1) = ']';
        *(log_data + pack_pos_info->pack_pos[i].tail * 3 + 2) = '\n';
      }else{
        free(log_buf);
        return -1;
      }
    }
  }

  recordInvalidData(c, log_buf, log_buf_len);
  free(log_buf);
  return 0;
}

