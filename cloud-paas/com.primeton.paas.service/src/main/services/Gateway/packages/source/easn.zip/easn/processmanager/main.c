#include <unistd.h>
#include <stdio.h>
#include <errno.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#ifndef WIN32
#include <sys/types.h>
#include <sys/wait.h>
#else
#define WNOHANG         0x00000001
#define WIFEXITED(a)    a
#define WEXITSTATUS(a)  a
extern int errno;
#define SIGCHLD         17
void wait() {
}
int waitpid() {
}
int fork() {
}
int sigset() {
}
#endif

#define MAX_PARMAS_COUN 20

typedef struct {
	int pid;
	char command[1024];
} ExecCommand;

int isSpace(char x) {
	return ((x) == ' ' || (x) == '\r' || (x) == '\n' || (x) == '\f'
			|| (x) == '\b' || (x) == '\t');
}

/*
 * Remove any tabs and spaces from the begining and the end of
 * a string
 */
char* trim(char* _s) {
	int len;
	char* end;

	/* Null pointer, there is nothing to do */
	if (!_s)
		return _s;

	/* Remove spaces and tabs from the begining of string */
	while (isSpace(*_s))
		_s++;

	len = strlen(_s);

	end = _s + len - 1;

	/* Remove trailing spaces and tabs */
	while (isSpace(*end))
		end--;
	if (end != (_s + len - 1)) {
		*(end + 1) = '\0';
	}

	return _s;
}

int parseConfig(char *aszFileName, ExecCommand *pExecCommand,
		int maxConfigItemCount) {
	FILE* fp;
	int configCount = 0;
	char szLineBuf[1024];
	if ((fp = fopen(aszFileName, "r")) == NULL) {
		printf("file open failed!\n");
		return 0;
	}
	szLineBuf[sizeof(szLineBuf) - 1] = '\0';
	while (fgets(szLineBuf, sizeof(szLineBuf) - 1, fp) != NULL) {
		printf("\n---%s----\n", szLineBuf);
		char *line = trim(szLineBuf);
		if ((*line == '#') || (*line == '\0'))
			continue;
		char *p = strchr(line, '#');
		if (p != NULL)
			*p = '\0'; //去掉说明字符
		strcpy(pExecCommand[configCount].command, line);
		pExecCommand[configCount].pid = 0;
		configCount++;
		if (configCount >= maxConfigItemCount)
			break;
	}
	fclose(fp);
	return configCount;
}

void sighandler(int sig) {
	printf("----- In signal handler for signal %d\n", sig);
	/* wait() is the key to acknowledging the SIGCHLD */
	wait(0);
}
int checkProcessRuning(int pid) {
	int status = 0, pr;
	pr = waitpid(pid, &status, WNOHANG);
	//printf("\n-----pid =%d,  pr= %d, status=%d \n",pid, pr,status);
	return (pr == 0);
}

int executeCommand(char *cmd) {
	int i, j, tag, cmdlen;
	char cmdBuffer[1024];
	char *cmd_arg[MAX_PARMAS_COUN];
	/* 把命令行分解为指针数组cmd_arg */
	memset(cmd_arg, 0, sizeof(cmd_arg));
	strncpy(cmdBuffer, cmd, sizeof(cmdBuffer));
	i = 0;
	j = 0;
	tag = 0;
	cmdlen = strlen(cmdBuffer);
	while (i < cmdlen && j < MAX_PARMAS_COUN) {

		if ((cmdBuffer[i] == ' ') || (cmdBuffer[i] == '\t')) {
			cmdBuffer[i] = '\0';
			tag = 0;
		} else {
			if (tag == 0)
				cmd_arg[j++] = cmdBuffer + i;
			tag = 1;
		}
		i++;
	}

	/* 如果参数超过10个，就打印错误，并忽略当前输入 */
	if (j >= MAX_PARMAS_COUN && i < cmdlen) {
		printf("TOO MANY ARGUMENTS\n");
		return -1;
	}
	return executeProcess(cmd_arg);
}
/* 执行外部命令或应用程序 */
int executeProcess(char *argv[]) {
	pid_t pid;

	pid = fork();
	if (pid < 0) {
		printf("SOME ERROR HAPPENED IN FORK\n");
		exit(2);
	} else if (pid == 0) {
		if (execvp(argv[0], argv) < 0)
			switch (errno) {
			case ENOENT:
				printf("COMMAND OR FILENAME NOT FOUND\n");
				break;
			case EACCES:
				printf("YOU DO NOT HAVE RIGHT TO ACCESS\n");
				break;
			default:
				printf("SOME ERROR HAPPENED IN EXEC\n");
			}
		exit(3);
	} else {
		return pid;
	}
}
#define MAX_PROCESS_COUNT  256
int main(void) {
	int i, j, configCount;
	ExecCommand *pExecCommand = (ExecCommand *) malloc(
			MAX_PROCESS_COUNT * sizeof(ExecCommand));
	memset(pExecCommand, 0, MAX_PROCESS_COUNT * sizeof(ExecCommand));
	configCount = parseConfig("process-manager.conf", pExecCommand,
			MAX_PROCESS_COUNT);
	printf("\n config item count=%d", configCount);
	sigset(SIGCHLD, &sighandler);
	while (configCount > 0) {
		for (i = 0; i < configCount; i++) {

			if (pExecCommand[i].pid <= 0) {
				pExecCommand[i].pid = executeCommand(pExecCommand[i].command);
				printf("\n-----------pid=%d--cmdLine=%s-----\n",
						pExecCommand[i].pid, pExecCommand[i].command);
			} else {
				if (!checkProcessRuning(pExecCommand[i].pid)) {
					printf("pid=%d, cmdLine=%s   is exit()",
							pExecCommand[i].pid, pExecCommand[i].command);
					pExecCommand[i].pid = 0;
				}

			}
		}
		sleep(1);
	}
	return 0;
}
