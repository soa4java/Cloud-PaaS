#include "fes_698tcps.h"
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <getopt.h>
#include <time.h>
#include <sys/stat.h>
#include <net/zmalloc.h>

#include "comm/fes_698_comm.h"
#include "protocol/protocolmanager.h"

static char gatewayNum = 0;
static char doping = 0;


static unsigned long long sendmsgnum = 0;

static int masterCount = 0;
static int bindMasterCount = 0;

MasterAddress mAddress[MAX_MASTER];
RecordBuffer recordBuffer;
RecordBuffer recordinvalidBuffer;

Fes698TcpsServer server;

static void readDataFromClient(aeEventLoop *el, int fd, void *privdata,	int mask);
static void readDataFromMaster(aeEventLoop *el, int fd, void *privdata,	int mask);
static void freeMaster(Fes698TcpsMaster *m);

void connectMaster();
void printTime();
void sendRecordedFile();

Fes698TcpsMaster *getShortestReplyListMaster();
#define MAX_MSA 128
Fes698TcpsMaster *msa[MAX_MSA];
void init_msa();

#define TRACE()    printf("\n----- %s %d",__FILE__,__LINE__)

void init_msa()
{
  memset(msa, 0, sizeof(msa));
}

static int clientsCronHandleTimeout(Fes698TcpsClient *c) {
	time_t now = server.unixtime;
	//增加对绑定主站通讯的检查
	char address[32] = { 0 };
	if ((c->masterfd > 0) && (now - c->bindtime > server.maxbindtime)) {
		sprintf(address, "%d.%d.%d.%d:%d#%d", c->remote.sin_addr.s_addr & 0xFF,
				(c->remote.sin_addr.s_addr >> 8) & 0xFF,
				(c->remote.sin_addr.s_addr >> 16) & 0xFF,
				(c->remote.sin_addr.s_addr >> 24) & 0xFF,
				ntohs(c->remote.sin_port), c->fd);
		printTime();
		printf("clientMasterBindTimeout: %s\n", address);
		c->masterfd = 0;
	}

	if (server.maxidletime && (now - c->lastinteraction > server.maxidletime)) {
		sprintf(address, "%d.%d.%d.%d:%d#%d", c->remote.sin_addr.s_addr & 0xFF,
				(c->remote.sin_addr.s_addr >> 8) & 0xFF,
				(c->remote.sin_addr.s_addr >> 16) & 0xFF,
				(c->remote.sin_addr.s_addr >> 24) & 0xFF,
				ntohs(c->remote.sin_port),c->fd);
		printTime();
		printf("clientsCronHandleTimeout: %s\n", address);
		freeClient(c, CTRL_CLOSE);
		return 1;
	}
	return 0;
}

void clientsCron(void) {
	/* Make sure to process at least 1/(server.hz*10) of clients per call.
	 * Since this function is called server.hz times per second we are sure that
	 * in the worst case we process all the clients in 10 seconds.
	 * In normal conditions (a reasonable number of clients) we process
	 * all the clients in a shorter time. */
//    int numclients = listLength(server.clients);
	int iterations = 800;
	while (listLength(server.clients) && iterations--) {
		Fes698TcpsClient *c;
		listNode *head;

		/* Rotate the list, take the current head, process.
		 * This way if the client must be removed from the list it's the
		 * first element and we don't incur into O(N) computation. */
		listRotate(server.clients);
		head = listFirst(server.clients);
		c = listNodeValue(head);
		/* The following functions do different service checks on the client.
		 * The protocol is that they return non-zero if the client was
		 * terminated. */
		if (clientsCronHandleTimeout(c))
			continue;
	}
}

static void checkClinets() {
	if (server.clients == NULL) {
		printTime();
		printf("clients is NULL\n");
	} else {
		printTime();
		printf("port:%d,clients is %d,send num is:%u\n", server.port,
				(listLength(server.clients)), sendmsgnum);
	}
}

/* Check for timeouts. Returns non-zero if the client was terminated */

static int serverCron(struct aeEventLoop *eventLoop, long long id,
		void *clientData) {
	FES_NOTUSED(eventLoop);
	FES_NOTUSED(id);
	FES_NOTUSED(clientData);
	clientsCron();
	checkClinets();
	return 10000; //10s扫描一次
}

/* Check for timeouts. Returns non-zero if the master was terminated */

static int masterCron(struct aeEventLoop *eventLoop, long long id,
		void *clientData) {
	FES_NOTUSED(eventLoop);
	FES_NOTUSED(id);
	FES_NOTUSED(clientData);
	int i;
	for (i = 0; i < getMasterCount(); i++) {
		if (server.master[i] == NULL) {
			connectMaster(i);
			writeToMasterGWResetMsg(server.master[i]);
		} else {
			server.master[i]->open++;
		}
	}
	recordData(NULL, 0);
	return 1000;
}

Fes698TcpsClient *getActiveClient(int fd) {
	return aeGetFileClientData(server.el, fd);
}
static void sigtermHandler(int sig) {
	FES_NOTUSED(sig);
	printTime();
	printf("Received SIGTERM, scheduling shutdown...");
	server.shutdown = 1;
}

static void initServerConfig() {
	server.ipfd = -1;
	server.maxclients = 1024;
	server.port = 9991;
	server.tcpkeepalive = 60; //60秒
	server.mastertcpkeepalive = 15; //15秒
	server.maxidletime = 10 * 60; //十分钟
	server.maxbindtime = 5 * 60; //一小时
	strcpy(server.transmissionQueueName, "fes_tpcs");
	strcpy(server.analystQueueName, "fes_3761");
}

static void sendDataToClient(aeEventLoop *el, int fd, void *privdata, int mask) {
	Fes698TcpsClient *c = privdata;
	sds *ptr;
	int nwritten = 0, totwritten = 0, objlen;
	FES_NOTUSED(el);
	FES_NOTUSED(mask);

	while (c->bufpos > 0 || listLength(c->reply)) {
		if (c->bufpos > 0) {
			nwritten = write(fd, c->buf + c->sentlen, c->bufpos - c->sentlen);
			if (nwritten <= 0)
				break;
			c->sentlen += nwritten;
			totwritten += nwritten;

			/* If the buffer was sent, set bufpos to zero to continue with
			 * the remainder of the reply. */
			if (c->sentlen == c->bufpos) {
				c->bufpos = 0;
				c->sentlen = 0;
			}
		} else {
			ptr = listNodeValue(listFirst(c->reply));
			objlen = sdslen(ptr);
			if (objlen == 0) {
				listDelNode(c->reply, listFirst(c->reply));
				continue;
			}
			nwritten = write(fd, ((char*) ptr) + c->sentlen,
					objlen - c->sentlen);
			if (nwritten <= 0)
				break;
			c->sentlen += nwritten;
			totwritten += nwritten;

			/* If we fully sent the object on head go to the next one */
			if (c->sentlen == objlen) {
				listDelNode(c->reply, listFirst(c->reply));
				c->sentlen = 0;
			}
		}
	}
	if (nwritten == -1) {
		if (errno == EAGAIN) {
			nwritten = 0;
		} else {
			printTime();
			printf("Error writing to client: %s\n", strerror(errno));
			freeClient(c, 0);
			return;
		}
	}
	if (totwritten > 0)
		c->lastinteraction = server.unixtime;
	if (c->bufpos == 0 && listLength(c->reply) == 0) {
		c->sentlen = 0;
		aeDeleteFileEvent(server.el, c->fd, AE_WRITABLE);
	}
}

static void sendDataToMaster(aeEventLoop *el, int fd, void *privdata, int mask) {
	Fes698TcpsMaster *m = privdata;
	sds *ptr;
	int nwritten = 0, totwritten = 0, objlen;
	FES_NOTUSED(el);
	FES_NOTUSED(mask);

	while (m->bufpos > 0 || listLength(m->reply)) {
		if (m->bufpos > 0) {
			nwritten = write(fd, m->buf + m->sentlen, m->bufpos - m->sentlen);
			if (nwritten <= 0)
				break;

			m->sentlen += nwritten;
			totwritten += nwritten;

			/* If the buffer was sent, set bufpos to zero to continue with
			 * the remainder of the reply. */
			if (m->sentlen == m->bufpos) {
				m->bufpos = 0;
				m->sentlen = 0;
			}
		} else {
			ptr = listNodeValue(listFirst(m->reply));
			objlen = sdslen(ptr);
			if (objlen == 0) {
				listDelNode(m->reply, listFirst(m->reply));
				continue;
			}
			nwritten = write(fd, ((char*) ptr) + m->sentlen,
					objlen - m->sentlen);
			if (nwritten <= 0)
				break;
			m->sentlen += nwritten;
			totwritten += nwritten;

			/* If we fully sent the object on head go to the next one */
			if (m->sentlen == objlen) {
				listDelNode(m->reply, listFirst(m->reply));
				m->sentlen = 0;
			}
		}

	}
	if (nwritten == -1) {
		if (errno == EAGAIN) {
			nwritten = 0;
		} else {
			printTime();
			printf("Error writing to master: %s", strerror(errno));
			freeMaster(m);
			return;
		}
	}
	if (totwritten > 0)
		m->lastinteraction = server.unixtime;
	if (m->bufpos == 0 && listLength(m->reply) == 0) {
		m->sentlen = 0;
		aeDeleteFileEvent(server.el, m->fd, AE_WRITABLE);
	}
}

static int prepareClientToWrite(Fes698TcpsClient *c) {
	if (c->fd <= 0)
		return -1; /* Fake client */
	if (c->bufpos
			== 0&& listLength(c->reply) == 0 && aeCreateFileEvent(server.el, c->fd, AE_WRITABLE,
					sendDataToClient, c) == AE_ERR)
		return -1;
	return 0;
}

//准备主站，开始写操作
static int prepareMasterToWrite(Fes698TcpsMaster *m) {
	if (m->fd <= 0)
		return -1; /* Fake master */
	if (m->bufpos
			== 0&& listLength(m->reply) == 0 &&
			aeCreateFileEvent(server.el, m->fd, AE_WRITABLE, sendDataToMaster, m) == AE_ERR)
		return -1;
	return 0;
}

int writeDataToClient(Fes698TcpsClient *c, char *buf, int length) {
	if (c != NULL) {
		if (0 == prepareClientToWrite(c))
			recordData(buf, length);
		int leftSize = sizeof(c->buf) - c->bufpos;
		if (length <= leftSize) {
			memcpy(c->buf + c->bufpos, buf, length);
			c->bufpos += length;
		} else {
			sds newBuf = sdsnewlen(buf, length);
			listAddNodeTail(c->reply, newBuf);
		}
	}
	return length;
}

Fes698TcpsMaster *getShortestReplyListMaster() {
	int i, j;
	Fes698TcpsMaster *m = NULL;
	static int lastMaster = 0;

	for (j = 0; j < masterCount; j++) {
		i = (j + lastMaster) % masterCount;
		//20140627 add server.master[i]->bind == 0
		if ((server.master[i] != NULL) && (server.master[i]->open > 0)
				&& (server.master[i]->bind == 0)) {
			m = server.master[i];
			if (m->reply->len > MAX_MASTER_REPLY) {
				printf("master reply len over buffer\n");
				freeMaster(m);
				m = NULL;
			}
			lastMaster = i + 1;
			break;
		} else {
			continue;
		}
	}
	return m;
}

//向主站写数据
int writeDataToMaster(Fes698TcpsMaster *m, char *buf, int length) {
	if (m != NULL) {
		if (0 == prepareMasterToWrite(m))
			sendmsgnum++;
		int leftSize = sizeof(m->buf) - m->bufpos;
		if (length <= leftSize) {
			memcpy(m->buf + m->bufpos, buf, length);
			m->bufpos += length;
		} else {
			sds newBuf = sdsnewlen(buf, length);
			listAddNodeTail(m->reply, newBuf);
		}
	}
	return length;
}

int addToWriteBuffer(int fd, char *buf, int length) {
	Fes698TcpsClient *c = aeGetFileClientData(server.el, fd);
	writeDataToClient(c, buf, length);
	return 0;
}

//将数据加入主站写缓存,不需要指定句柄
int addToMasterWriteBufferEx(char *buf, int length) {
  char msa_value;     
  Fes698TcpsMaster *m; 
  if( (buf[MIN_MASTER_MSG_SIZE+6]>>6) & 0x01 == 1){
    m = getShortestReplyListMaster();
  }else{
    msa_value = buf[MIN_MASTER_MSG_SIZE+11] >>1;  
    m = msa[msa_value];
  }
  writeDataToMaster(m, buf, length);
  return 0;
}

//将数据加入主站写缓存
int addToMasterWriteBuffer(int fd, char *buf, int length) {
	Fes698TcpsMaster *m = aeGetFileClientData(server.el, fd);
	writeDataToMaster(m, buf, length);
	return 0;
}
#define true  1
#define false 0
#define BLOCK_START_SIGN  0x68
#define BLOCK_END_SIGN    0x16
#define MASTER_START_SIGN 0xA8

int processDataFrame(Fes698TcpsClient *c, char *frameHead, int frameSize) {
	return writeToNextProc(c, frameHead, frameSize);
	//return writeDataToClient(c,frameHead,frameSize);
}

static int processMasterDataFrame(Fes698TcpsMaster *m, char *frameHead,
		int frameSize) {
	return writeToMasterNextProc(m, frameHead, frameSize);
}
static int processInputBuffer(Fes698TcpsClient *c) {
	return unpackFrame(c);
}

static int processMasterInputBuffer(Fes698TcpsMaster *m) {
	int bufSize = m->readbufpos;

	int startPosition = 0;
	int findHead, i;
	int frameCount = 0;
	char * head = (char *) m->readbuf;

//	char msg[256] = {0};
//	memcpy(msg, head, bufSize);
//	printHexCode(msg,bufSize);

	int enough = true;
	while (true) {
		if ((bufSize - startPosition < MIN_MASTER_MSG_SIZE))
			enough = false;
		findHead = false;
		if (!enough) {
			int leftBufSize = bufSize - startPosition;
			if (leftBufSize > 0)
				memcpy(head, head + startPosition, leftBufSize);
			m->readbufpos = leftBufSize;
			return frameCount;
		}
		for (i = startPosition; i < (bufSize - MIN_MASTER_MSG_SIZE + 1); i++) {
			if ((head[i] & 0xFF) == MASTER_START_SIGN) {
				findHead = true;
				int len = (head[i + 1] & 0xFF)	+ (((int) (head[i + 2] & 0xff)) << 8);
				int packageSize = len + MIN_MASTER_MSG_SIZE;
				if (bufSize < i + packageSize) {
					enough = false;
					break;
				}
				processMasterDataFrame(m, head + i, packageSize);
				++frameCount;
				startPosition = i + packageSize;
				break;
			}
		}
		if (!findHead) {
			startPosition = bufSize - MIN_MASTER_MSG_SIZE + 1;
		}
	}
	return frameCount;
}

void freeClient(Fes698TcpsClient *c, int type) {
	listNode *ln;
	/* If this is marked as current client unset it */
	//向数据分析层发送关闭事件
//	writeToNextProc(c,NULL,0);
	writeToMasterConnCloseMsg(c, type);

	if (server.current_client == c)
		server.current_client = NULL;

	/* Note that if the client we are freeing is blocked into a blocking
	 * call, we have to set querybuf to NULL *before* to call
	 * unblockClientWaitingData() to avoid processInputBuffer() will get
	 * called. Also it is important to remove the file events after
	 * this, because this call adds the READABLE event. */

	/* Obvious cleanup */
	aeDeleteFileEvent(server.el, c->fd, AE_READABLE);
	aeDeleteFileEvent(server.el, c->fd, AE_WRITABLE);
	aeCleanFileClientData(server.el, c->fd);
	listRelease(c->reply);
	close(c->fd);
	/* Remove from the list of clients */
	ln = listSearchKey(server.clients, c);
	if (ln != NULL) {
		listDelNode(server.clients, ln);
	}
	zfree(c);
}

static void freeMaster(Fes698TcpsMaster *m) {
	listNode *ln;
	/* Note that if the client we are freeing is blocked into a blocking
	 * call, we have to set querybuf to NULL *before* to call
	 * unblockClientWaitingData() to avoid processInputBuffer() will get
	 * called. Also it is important to remove the file events after
	 * this, because this call adds the READABLE event. */

	/* Obvious cleanup */
	aeDeleteFileEvent(server.el, m->fd, AE_READABLE);
	aeDeleteFileEvent(server.el, m->fd, AE_WRITABLE);
	aeCleanFileClientData(server.el, m->fd);
	listRelease(m->reply);

	close(m->fd);
	/* Remove from the list of clients */
	ln = listSearchKey(server.clients, m);
	if (ln != NULL) {
		listDelNode(server.clients, ln);
	}

	int i;
	for (i = 0; i < getMasterCount(); i++) {
		if (server.master[i] == m) {
			server.master[i] = NULL;
			break;
		}
	}
	zfree(m);
}

static Fes698TcpsClient *createClient(int fd) {
	Fes698TcpsClient *c = (Fes698TcpsClient *) zmalloc(
			sizeof(Fes698TcpsClient));
	/* passing -1 as fd it is possible to create a non connected client.
	 * This is useful since all the Redis commands needs to be executed
	 * in the context of a client. When commands are executed in other
	 * contexts (for instance a Lua script) we need a non connected client. */
	if (fd != -1) {
		anetNonBlock(NULL, fd);
		anetEnableTcpNoDelay(NULL, fd);
		if (server.tcpkeepalive)
			anetKeepAlive(NULL, fd, server.tcpkeepalive);
		if (aeCreateFileEvent(server.el, fd, AE_READABLE, readDataFromClient,
				c) == AE_ERR) {
			close(fd);
			zfree(c);
			return NULL;
		}
	}
	memset(c, 0, sizeof(Fes698TcpsClient));
	c->fd = fd;
	socklen_t adrLen = sizeof(c->remote);
	getpeername(fd, (__SOCKADDR_ARG) &(c->remote), &adrLen);
	adrLen = sizeof(c->local);
	getsockname(fd, (__SOCKADDR_ARG) &(c->local), &adrLen);
	c->ctime = c->lastinteraction = server.unixtime;
	c->reply = listCreate();
	c->reply->free = sdsfree;
	if (fd != -1)
		listAddNodeTail(server.clients, c);
	return c;
}

static Fes698TcpsMaster *createMaster(int fd) {
	Fes698TcpsMaster *m = (Fes698TcpsMaster *) zmalloc(
			sizeof(Fes698TcpsMaster));
	/* passing -1 as fd it is possible to create a non connected client.
	 * This is useful since all the Redis commands needs to be executed
	 * in the context of a client. When commands are executed in other
	 * contexts (for instance a Lua script) we need a non connected client. */
	if (fd != -1) {
		anetNonBlock(NULL, fd);
		anetEnableTcpNoDelay(NULL, fd);
		if (server.mastertcpkeepalive)
			anetKeepAlive(NULL, fd, server.mastertcpkeepalive);
		if (aeCreateFileEvent(server.el, fd, AE_READABLE, readDataFromMaster,
				m) == AE_ERR) {
			close(fd);
			zfree(m);
			return NULL;
		}
	}
	memset(m, 0, sizeof(Fes698TcpsMaster));
	m->fd = fd;
	socklen_t adrLen = sizeof(m->remote);
	getpeername(fd, (__SOCKADDR_ARG) &(m->remote), &adrLen);
	adrLen = sizeof(m->local);
	getsockname(fd, (__SOCKADDR_ARG) &(m->local), &adrLen);
	m->ctime = m->lastinteraction = server.unixtime;
	m->reply = listCreate();
	m->reply->free = sdsfree;
	return m;
}
static void readDataFromClient(aeEventLoop *el, int fd, void *privdata,
		int mask) {
	Fes698TcpsClient *c = (Fes698TcpsClient*) privdata;
	char address[32] = {0};
	sprintf(address, "%d.%d.%d.%d:%d#%d", c->remote.sin_addr.s_addr & 0xFF,
			(c->remote.sin_addr.s_addr >> 8) & 0xFF,
			(c->remote.sin_addr.s_addr >> 16) & 0xFF,
			(c->remote.sin_addr.s_addr >> 24) & 0xFF,
			ntohs(c->remote.sin_port),c->fd);
	int nread, readlen;
	FES_NOTUSED(el);
	FES_NOTUSED(mask);

	server.current_client = c;
	readlen = sizeof(c->readbuf) - c->readbufpos;
	if ((c->readbufpos > 8 * 1024) && (c->protype < 1)) {
		printTime();
		printf("protype<1 : %d\n", c->fd);
		freeClient(c, 0);
		return;
	}
	nread = read(fd, c->readbuf + c->readbufpos, readlen);
	//printf("\n pos=%d length=%d",c->readbufpos,nread);
	if (nread == -1) {
		if (errno == EAGAIN) {
			nread = 0;
		} else {
			printTime();
			printf("Reading from client:%s,errno:%d, %s\n", address, errno, strerror(errno));
			freeClient(c, 0);
			return;
		}
	} else if (nread == 0) {
		printTime();
		printf("Client closed connection:%s\n", address);
		freeClient(c, 0);
		return;
	}
	if (nread) {
		c->readbufpos += nread;
		c->lastinteraction = server.unixtime;
	} else {
		server.current_client = NULL;
		return;
	}
	processInputBuffer(c);
	server.current_client = NULL;
}

static void readDataFromMaster(aeEventLoop *el, int fd, void *privdata,
		int mask) {
	Fes698TcpsMaster *m = (Fes698TcpsMaster*) privdata;
	int nread, readlen;
	FES_NOTUSED(el);
	FES_NOTUSED(mask);

	readlen = sizeof(m->readbuf) - m->readbufpos;
	nread = read(fd, m->readbuf + m->readbufpos, readlen);
	//printf("\n pos=%d length=%d",c->readbufpos,nread);
	if (nread == -1) {
		if (errno == EAGAIN) {
			nread = 0;
		} else {
			printf("Reading from master: %s\n", strerror(errno));
			freeMaster(m);
			return;
		}
	} else if (nread == 0) {
		printf("Master closed connection\n");
		freeMaster(m);
		return;
	}
	if (nread) {
		m->readbufpos += nread;
		m->lastinteraction = server.unixtime;
	} else {
		return;
	}
	processMasterInputBuffer(m);
}
static void acceptCommonHandler(int fd, int flags) {
	Fes698TcpsClient *c;
	if ((c = createClient(fd)) == NULL) {
		printTime();
		printf("Error registering fd event for the new client: %s (fd=%d)",
				strerror(errno), fd);
		close(fd); /* May be already closed, just ignore errors */
		return;
	}
	/* If maxclient directive is set and this is one client more... close the
	 * connection. Note that we create the client instead to check before
	 * for this condition, since now the socket is already set in non-blocking
	 * mode and we can send an error for free using the Kernel I/O */
	if (listLength(server.clients) > server.maxclients) {
		char *err = "-ERR max number of clients reached\r\n";

		/* That's a best effort error message, don't check write errors */
		if (write(c->fd, err, strlen(err)) == -1) {
			/* Nothing to do, Just to avoid the warning... */
		}
		server.stat_rejected_conn++;
		freeClient(c, 0);
		return;
	}
	server.stat_numconnections++;
	c->flags |= flags;
}

static void acceptTcpHandler(aeEventLoop *el, int fd, void *privdata, int mask) {
	int cport, cfd;
	char cip[128];
	FES_NOTUSED(el);
	FES_NOTUSED(mask);
	FES_NOTUSED(privdata);
	cfd = anetTcpAccept(server.neterr, fd, cip, &cport);
	if (cfd == AE_ERR) {
		printTime();
		printf("Accepting client connection: %s\n", server.neterr);
		return;
	}
	//printf("Accepted %s:%d", cip, cport);
	acceptCommonHandler(cfd, 0);
}

//static void acceptMasterTcpHandler(aeEventLoop *el, int fd, void *privdata, int mask) {
//	Fes698TcpsMaster *m;
//	if ((m = createMaster(fd)) == NULL) {
//		printf("Error registering fd event for the new master: %s (fd=%d)",
//				strerror(errno), fd);
//		close(fd); /* May be already closed, just ignore errors */
//		return;
//	}
//	writeToMasterNextProc(m, "abc", 4);
//	server.master = m;
//
////	int cport, cfd;
////	char cip[128];
////	FES_NOTUSED(el);
////	FES_NOTUSED(mask);
////	FES_NOTUSED(privdata);
////	cfd = anetTcpAccept(server.neterr, fd, cip, &cport);
////	if (cfd == AE_ERR) {
////		printf("Accepting master connection: %s", server.neterr);
////		return;
////	}
////	//printf("Accepted %s:%d", cip, cport);
////	acceptMasterCommonHandler(cfd, 0);
//}

void connectMaster(int masterIdx) {
	int masterfd = -1; //主站通讯句柄
	masterfd = anetTcpNonBlockConnect(server.neterr,
			mAddress[masterIdx].masterIP, mAddress[masterIdx].port);
	if (masterfd == ANET_ERR) {
		printTime();
		printf("masterfd == ANET_ERR\n");
		printf("connect masterip:%s,masterport:%d,err:%s\n",
				mAddress[masterIdx].masterIP, mAddress[masterIdx].port,
				server.neterr);
		exit(1);
	}
	printTime();
	printf("connect master, ip:%s,port:%d\n", mAddress[masterIdx].masterIP,
			mAddress[masterIdx].port);
	server.master[masterIdx] = createMaster(masterfd);
	server.master[masterIdx]->bind = mAddress[masterIdx].bind;
        msa[mAddress[masterIdx].msa]=server.master[masterIdx];
}

void connectAllMaster() {
	int i;
	for (i = 0; i < getMasterCount(); i++) {
		connectMaster(i);
		writeToMasterGWResetMsg(server.master[i]);
	}
}

void initRecordBuffer() {
	memset(&recordBuffer, 0, sizeof(RecordBuffer));
}

void initRecordInvalidBuffer() {
	memset(&recordinvalidBuffer, 0, sizeof(RecordBuffer));
}

void initServer() {
	server.current_client = NULL;
	server.clients = listCreate();
	server.clients_to_close = listCreate();
	server.el = aeCreateEventLoop(server.maxclients + getMasterCount());
	if (server.port != 0) {
		server.ipfd = anetTcpServer(server.neterr, server.port,
				server.bindaddr);
		if (server.ipfd == ANET_ERR) {
			printTime();
			printf("server.ipfd == ANET_ERR\n");
			printf("Opening port %d: %s\n", server.port, server.neterr);
			exit(1);
		}
	}
	printTime();
	printf("Opening server port %d: %d\n", server.port, server.ipfd);
	if (server.ipfd > 0 && aeCreateFileEvent(server.el, server.ipfd,
	AE_READABLE, acceptTcpHandler, NULL) == AE_ERR) {
		printTime();
		printf("Unrecoverable error creating server.ipfd file event.\n");
	}

	if (aeCreateTimeEvent(server.el, 1, serverCron, NULL, NULL) == AE_ERR) {
		printTime();
		printf("create time event failed\n");
		exit(1);
	}

	connectAllMaster();
	//添加和前置机周期任务
	if (aeCreateTimeEvent(server.el, 1, masterCron, NULL, NULL) == AE_ERR) {
		printTime();
		printf("create time event failed\n");
		exit(1);
	}
}
void setupSignalHandlers(void) {
	struct sigaction act;
	TRACE();
	/* When the SA_SIGINFO flag is set in sa_flags then sa_sigaction is used.
	 * Otherwise, sa_handler is used. */
	sigemptyset(&act.sa_mask);
	act.sa_flags = 0;
	act.sa_handler = sigtermHandler;
	sigaction(SIGTERM, &act, NULL);
	return;
}
void beforeSleep(struct aeEventLoop *eventLoop) {
	server.unixtime = time(NULL);
}

void daemonize(void) {
	int fd;

	if (fork() != 0)
		exit(0); /* parent exits */
	setsid(); /* create a new session */

	/* Every output goes to /dev/null. If Redis is daemonized but
	 * the 'logfile' is set to 'stdout' in the configuration file
	 * it will not log at all. */
	if ((fd = open("/dev/null", O_RDWR, 0)) != -1) {
		dup2(fd, STDIN_FILENO);
		dup2(fd, STDOUT_FILENO);
		dup2(fd, STDERR_FILENO);
		if (fd > STDERR_FILENO)
			close(fd);
	}
}

int main(int argc, char *argv[]) {

	int ch, i;

//	int isDaemonize;
	struct option longopts[] = {
			{ "destination", 1, NULL, 'd' },
			{ "binddestination", 1, NULL, 'b' },
			{ "serverport", 1, NULL, 'P' },
			{ "number", 1, NULL, 'n' },
			{ "maxclients", 1, NULL, 'm' },
			{ "timeout", 1, NULL, 't'},
			{ "doping", 1, NULL, 'p'},
			{ "help", 0, NULL, 'h' },
			{ "deamon",	0, NULL, 'D' },
			{ 0, 0, 0, 0 } };

	srand(time(NULL) ^ getpid());
	signal(SIGHUP, SIG_IGN);
	signal(SIGPIPE, SIG_IGN);
	initServerConfig();

//	isDaemonize = false;
	memset(mAddress, 0, sizeof(mAddress));
        init_msa();

	while ((ch = getopt_long(argc, argv, "d:b:P:n:m:t:p:hD?", longopts, NULL)) != -1) {
                
          char *p ;
		switch (ch) {
		case 'd':
			printf("\n option  destination %s  \n", optarg);
			for (i = 0; i < strlen(optarg); i++) {
				if (':' == optarg[i]) {
					memcpy(mAddress[masterCount].masterIP, optarg, i);
					mAddress[masterCount].port = (atoi(optarg + i + 1));
                                        mAddress[masterCount].bind = 0;
                                        if(p = strchr(optarg + i +1,':'))
                                        {
                                          mAddress[masterCount].msa = atoi(p +1);
                                          if((mAddress[masterCount].msa < 0) ||(mAddress[masterCount].msa >= MAX_MSA))
                                            break;
                                        masterCount++;
                                        break;

                                        }else{

                                        }
                                        //					printf("%s,%d\n",mAddress[masterCount].masterIP, mAddress[masterCount].port);
                                }
			}
			break;
		case 'b':
			printf("\n option bind destination %s  \n", optarg);
			for (i = 0; i < strlen(optarg); i++) {
				if (':' == optarg[i]) {
					memcpy(mAddress[masterCount].masterIP, optarg, i);
					mAddress[masterCount].port = (atoi(optarg + i + 1));
					mAddress[masterCount].bind = 1;
		//			printf("%s,%d\n",mAddress[masterCount].masterIP, mAddress[masterCount].port);
					masterCount++;
					bindMasterCount++;
					break;
				}
			}
			break;
//		case 'p':
//			printf("\n option  port  %s \n", optarg);
//			setMasterPort(atoi(optarg));
//			break;
		case 'P':
			printf("\n option  serverport  %s \n", optarg);
			server.port = atoi(optarg);
			break;
		case 'n':
			printf("\n option  number  %s \n", optarg);
			setGatewayNum(atoi(optarg));
			break;
		case 'm':
			printf("\n option  max clients  %s \n", optarg);
			server.maxclients = atoi(optarg);
			break;
		case 't':
			printf("\n option  max bind timeout(minute)  %s \n", optarg);
			server.maxbindtime = atoi(optarg) * 60;
			break;
		case 'p':
			printf("\n option  do ping  %s \n", optarg);
			doping = 1;
			break;
		default:
			printf("\n-d --ip:port   set master ip:port \n"
					"-b --ip:port set bind master ip:port \n"
					"-P --serverport set server port \n"
					"-n --number     set gateway number \n"
					"-m --number     set max clients \n"
					"-t --number     set max bind timeout(minute) \n"
					"-p --do ping\n"
					"-h --help help\n"
					"-D --deamon start as deamon\n");
			return 0;
			break;
		}
	}
//	recordDataTest();
	for (i = 0; i < masterCount; i++) {
		printTime();
		printf(
				"masterNum:%d,IP:%s;Port:%d;serverPort:%d;gatewayNum:%d;max:%d\n",
				i, mAddress[i].masterIP, mAddress[i].port, server.port,
				getGatewayNum(), server.maxclients);
	}

	//if(isDaemonize)daemonize();
	initProtocolManager();
	initServer();
	initRecordBuffer();
	aeSetBeforeSleepProc(server.el, beforeSleep);
	//anetTcpAccept(server.neterr, server.ipfd,ip,&port);
	//printf("\naccept =%s %d",ip,port);
	aeMain(server.el);
	aeDeleteEventLoop(server.el);

	return 0;
}

void setGatewayNum(char num) {
	gatewayNum = num;
}
char getGatewayNum() {
	return gatewayNum;
}

char getDoPing() {
	return doping;
}

int getMasterCount() {
	return masterCount;
}

int getBindMasterCount() {
	return bindMasterCount;
}

void recordData(char *data, int len) {
	//20140618，15分钟需要记录一个点
	static time_t lastRecordTime;
	time_t now = time(NULL);
	if (((lastRecordTime + MAX_TIME_INTERVAL) <= now)
			|| ((recordBuffer.bufpos + len + 4) >= MAX_RECORD_BUFFER)) {
		FILE *fp;
		time_t cur_time;
		struct tm *tmp_time;
		time(&cur_time);
		tmp_time = localtime(&cur_time);
		char filepath[32] = { 0 };
		char filename[32] = { 0 };
		memset(filepath, 0, sizeof(filepath));
		memset(filename, 0, sizeof(filename));
		sprintf(filepath, "datarate/%04d%02d%02d",
				2000 + (tmp_time->tm_year % 100), tmp_time->tm_mon + 1,
				tmp_time->tm_mday);

		mkdir("datarate", S_IRWXU);
		mkdir(filepath, S_IRWXU);

		sprintf(filename, "./%s/%02d%02d%02d@%02d", filepath, tmp_time->tm_hour,
				tmp_time->tm_min, tmp_time->tm_sec, getGatewayNum());
		fp = fopen(filename, "ab");
		fseek(fp, 0, SEEK_SET);
		fwrite(recordBuffer.buf, recordBuffer.bufpos, 1, fp);
		fclose(fp);
		initRecordBuffer();
		lastRecordTime = cur_time;
		recordData(data, len);
	} else {
		memcpy(recordBuffer.buf + recordBuffer.bufpos, data, len);
		recordBuffer.bufpos += len;
		memcpy(recordBuffer.buf + recordBuffer.bufpos, &now, 4);
		recordBuffer.bufpos += 4;
	}
}

void recordInvalidData(Fes698TcpsClient *c, char *data, int len)
{
  //20140618，15分钟需要记录一个点
  static time_t lastRecordTime;
  time_t now = time(NULL);
  char *now_str = ctime(&now);
  int now_str_len = strlen(now_str);
  char address[32] = {0};

  sprintf(address, "%d.%d.%d.%d:%d", c->remote.sin_addr.s_addr & 0xFF,
      (c->remote.sin_addr.s_addr >> 8) & 0xFF,
      (c->remote.sin_addr.s_addr >> 16) & 0xFF,
      (c->remote.sin_addr.s_addr >> 24) & 0xFF,
      ntohs(c->remote.sin_port));
  int ip_port_len = strlen(address);

  if (lastRecordTime + MAX_TIME_INTERVAL <= now
      || recordinvalidBuffer.bufpos + now_str_len + ip_port_len + len >= MAX_RECORD_INVALID_BUFFER) {
  //if (((lastRecordTime + MAX_TIME_INTERVAL) <= now)
  //		|| ((recordinvalidBuffer.bufpos + len ) >= MAX_RECORD_INVALID_BUFFER)) {
    FILE *fp;
    time_t cur_time;
    struct tm *tmp_time;
    time(&cur_time);
    tmp_time = localtime(&cur_time);
    char filepath[32] = { 0 };
    char filename[32] = { 0 };
    memset(filepath, 0, sizeof(filepath));
    memset(filename, 0, sizeof(filename));
    sprintf(filepath, "datarate_invalid/%04d%02d%02d",
        2000 + (tmp_time->tm_year % 100), tmp_time->tm_mon + 1,
        tmp_time->tm_mday);

    mkdir("datarate_invalid", S_IRWXU);
    mkdir(filepath, S_IRWXU);

    sprintf(filename, "./%s/%02d%02d%02d@%02d", filepath, tmp_time->tm_hour,
        tmp_time->tm_min, tmp_time->tm_sec, getGatewayNum());
    fp = fopen(filename, "ab");
    fseek(fp, 0, SEEK_SET);
    fwrite(recordinvalidBuffer.buf, recordinvalidBuffer.bufpos, 1, fp);
    fclose(fp);
    initRecordInvalidBuffer();
    lastRecordTime = cur_time;
    recordInvalidData(c, data, len);
  } else {
    now_str[now_str_len - 1] = ' ';
    memcpy(recordinvalidBuffer.buf + recordinvalidBuffer.bufpos, now_str, now_str_len);
    recordinvalidBuffer.bufpos += now_str_len;
    memcpy(recordinvalidBuffer.buf + recordinvalidBuffer.bufpos, address, ip_port_len);
    recordinvalidBuffer.bufpos += ip_port_len;
    memcpy(recordinvalidBuffer.buf + recordinvalidBuffer.bufpos, data, len);
    recordinvalidBuffer.bufpos += len;
  }
}

void recordDataTest() {
	initRecordBuffer();
	char msg1[] = { 0x68, 0x32, 0x00, 0x32, 0x00, 0x68, 0xC9, 0x23, 0x22, 0xAE,
			0x08, 0x00, 0x02, 0x70, 0x00, 0x00, 0x04, 0x00, 0x3A, 0x16 };
	char msg2[] = { 0x68, 0x4A, 0x00, 0x4A, 0x00, 0x68, 0x0B, 0x23, 0x22, 0xAE,
			0x08, 0x00, 0x00, 0x60, 0x00, 0x00, 0x04, 0x00, 0x02, 0x00, 0x00,
			0x04, 0x00, 0x00, 0x70, 0x16 };
	char msg3[] = { 0x68, 0x32, 0x00, 0x32, 0x00, 0x68, 0xC9, 0x23, 0x23, 0xAE,
			0x08, 0x00, 0x02, 0x70, 0x00, 0x00, 0x04, 0x00, 0x3B, 0x16 };
	char msg4[] = { 0x68, 0x4A, 0x00, 0x4A, 0x00, 0x68, 0x0B, 0x23, 0x23, 0xAE,
			0x08, 0x00, 0x00, 0x60, 0x00, 0x00, 0x04, 0x00, 0x02, 0x00, 0x00,
			0x04, 0x00, 0x00, 0x71, 0x16 };
	int k;
	for (k = 0; k < 100000; k++) {
		recordData(msg1, 20);
		recordData(msg2, 26);
	}
	for (k = 0; k < 300000; k++) {
		recordData(msg3, 20);
		recordData(msg4, 26);
	}
}
