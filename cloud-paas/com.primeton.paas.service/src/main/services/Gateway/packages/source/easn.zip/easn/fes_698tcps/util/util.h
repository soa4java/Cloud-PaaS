#ifndef UTIL_H_
#define UTIL_H_
#include <stdio.h>
#include <time.h>
#include <string.h>
#include <unistd.h>
void printTime();
void printHexCode(char * data,int dataLength);

#endif
