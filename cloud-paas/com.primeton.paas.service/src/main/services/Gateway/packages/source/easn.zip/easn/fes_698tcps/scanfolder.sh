#!/bin/bash 
echo `date` 
ABSOLUTE_PATH=$(cd "$(dirname "$0")"; pwd)
MAIN_FOLDER=$ABSOLUTE_PATH"/"datarate
FTP_IP=172.22.142.8
U_NAME=weblogic
U_PSW=weblogic

DO_FTP=1
IF_FTP=$DO_FTP

fsize=$(/bin/ls -l $ABSOLUTE_PATH/nohup.out | cut -d' ' -f 5)
maxsize=1024
((maxsize*=1024)) 
((maxsize*=100)) 
if [[ $maxsize -lt $fsize ]]
then
    logname=`date +%Y%m%d%H%M%S`
    cat $ABSOLUTE_PATH/nohup.out > $ABSOLUTE_PATH/$logname
    cat /dev/null > $ABSOLUTE_PATH/nohup.out
fi 

if [[ $DO_FTP -eq $IF_FTP ]]
then
    cd $MAIN_FOLDER
    for folder in `ls -1tr`
    do
        if [[ -z `ls -1tr $folder` ]]
        then
            rm -rf $folder
            echo "rm:"$folder
        elif [ -d "$folder" ] 
        then
            #echo $folder
            for file in `ls -1tr $folder`
            do          
                bash $ABSOLUTE_PATH/transferfile.sh $FTP_IP $U_NAME $U_PSW $ABSOLUTE_PATH $MAIN_FOLDER $folder $file  
            done
        else
            #rm $folder
            echo "rm..."$folder
        fi
    done 
fi
echo "bingo!"
