#ifndef PROTOCOL_MANAGER_H_
#define PROTOCOL_MANAGER_H_
#include <stdint.h>
#include <stdio.h>
#include "tcps/fes_698tcps.h"

#define PROTYPE_3761   0xF0
#define PROTYPE_HENAN  0xF1//河南省规约
#define PROTYPE_04     0xF2//电力负荷管理系统数据传输规约－2004

#define ELEMENTS_COUNT(a)        (sizeof(a)/sizeof(a[0]))

typedef int (*checkProtocol)(Fes698TcpsClient *c);
typedef int (*unpackData)(Fes698TcpsClient *c);
typedef int (*dopingData)(Fes698TcpsClient *c, char *data, int length);

typedef struct ProtocolModule {
	uint8_t proType;
	checkProtocol check;
	unpackData unpack;
	dopingData doping;
} ProtocolModule;

void initProtocolManager();
ProtocolModule *getProtocolModuleByData(Fes698TcpsClient *c);
ProtocolModule *getProtocolModuleByProType(int protype);
int unpackFrame(Fes698TcpsClient *c);
int dopingFrame(Fes698TcpsClient *c, uint8_t *data, int length);
#endif
