#!/bin/bash
FILE_PATH=$5"/"$6
ftp -n <<EOF>$4/ftp.log
open $1
user $2 $3
binary
mkdir $6
cd $6
lcd $FILE_PATH
ls
prompt
mput $7
bye
EOF
grep $7 $4/ftp.log
if [ $? -eq 0 ]
then
rm $FILE_PATH"/"$7
fi
