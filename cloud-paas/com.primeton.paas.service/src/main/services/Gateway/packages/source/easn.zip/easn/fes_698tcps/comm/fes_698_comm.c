#include "stdio.h"
#include "fes_698_comm.h"
#include "protocol/protocolmanager.h"

extern Fes698TcpsServer server;

//网关复位
int writeToMasterGWResetMsg(Fes698TcpsMaster *m){
	MasterMessage *sendData = (MasterMessage *)malloc(sizeof(MasterMessage));
	memset(sendData, 0, sizeof(MasterMessage));
	sendData->head = HEAD_SIGN;
	sendData->length = 0;
	sendData->ctrl = CTRL_RESET;
	sendData->dataType = 0xF|ADDTYPE_IPV4;
	sendData->addressFmt.fd = m->fd;
	sendData->addressFmt.gatewayNum = getGatewayNum();
	socklen_t adrLen = sizeof(m->local);
	getsockname(m->fd,(__SOCKADDR_ARG)&(m->local),&adrLen);
	sendData->addressFmt.port =ntohs(m->local.sin_port);
	sendData->addressFmt.ipv6d = (m->local.sin_addr.s_addr);
	addToMasterWriteBuffer(m->fd, (char *)sendData, sizeof(MasterMessage));
	free(sendData);
	return 0;
}

//连接关闭
int writeToMasterConnCloseMsg(Fes698TcpsClient *c, int type){
	MasterMessage *sendData = (MasterMessage *)malloc(sizeof(MasterMessage));
	memset(sendData, 0, sizeof(MasterMessage));
	sendData->head = HEAD_SIGN;
	sendData->length = 0;
	if (type == 0)
		sendData->ctrl = CTRL_CLOSE;
	else
		sendData->ctrl = type;
	sendData->dataType = (ADDTYPE_IPV4 << 4)|(c->protype & 0xF);
	sendData->addressFmt.fd = c->fd;
	sendData->addressFmt.gatewayNum = getGatewayNum();

	socklen_t adrLen = sizeof(c->remote);
	getpeername(c->fd,(__SOCKADDR_ARG)&(c->remote),&adrLen);
	sendData->addressFmt.port =ntohs(c->remote.sin_port);
	sendData->addressFmt.ipv6d = (c->remote.sin_addr.s_addr);
	addToMasterWriteBufferEx((char *)sendData, sizeof(MasterMessage));
	free(sendData);
	return 0;
}

int writeToNextProc(Fes698TcpsClient *c, const char *buf, const int length){
	/** 打印收到客户端数据信息
	char ip[16] = {0};
	sprintf(ip, "%d.%d.%d.%d",
			c->remote.sin_addr.s_addr & 0xFF,
			(c->remote.sin_addr.s_addr >> 8) & 0xFF,
			(c->remote.sin_addr.s_addr >> 16) & 0xFF,
			(c->remote.sin_addr.s_addr >> 24) & 0xFF);
	printTime();
	printf("recv client#%s#%d:", ip, c->fd);
	printHexCode((char *)buf, length);
	*/

	int allSize=sizeof(MasterMessage)+length;
	MasterMessage *sendData = (MasterMessage *)malloc(allSize);
	memset(sendData, 0, allSize);
	sendData->head = HEAD_SIGN;
	sendData->length = length;
	sendData->ctrl = CTRL_SEND;
	sendData->dataType = (ADDTYPE_IPV4 << 4)|(c->protype & 0xF);
	sendData->addressFmt.fd = c->fd;
	sendData->addressFmt.gatewayNum = getGatewayNum();
	sendData->addressFmt.port =ntohs(c->remote.sin_port);
	sendData->addressFmt.ipv6d = c->remote.sin_addr.s_addr;

	char * sendBuf = (char *)sendData+sizeof(MasterMessage);
	if(length>0){
		memcpy(sendBuf, buf, length);
	}
	if(c->masterfd > 0)
		addToMasterWriteBuffer(c->masterfd, (char *)sendData, allSize);
	else
		addToMasterWriteBufferEx((char *)sendData, allSize);

	/** 打印发送给服务端数据信息
	printTime();
	printf("send master#%s:", ip);
	printHexCode((char *)sendData, allSize);
	*/
	free(sendData);
	return 0;
}

int writeToMasterExecFailMsg(Fes698TcpsMaster *m, AddressFmt addressFmt,
		const char *buf, const int length) {
//	printf("send ExecFailMsg..................\n");

	int allSize = sizeof(MasterMessage) + length;
	MasterMessage *sendData = (MasterMessage *) malloc(allSize);
	sendData->head = HEAD_SIGN;
	sendData->length = length;
	sendData->ctrl = CTRL_FAIL;
	sendData->dataType = ADDTYPE_IPV4 | 0xF ;
	sendData->addressFmt = addressFmt;

	char * sendBuf = (char *) sendData + sizeof(MasterMessage);
	if (length > 0) {
		memcpy(sendBuf, buf, length);
	}
	addToMasterWriteBuffer(m->fd, (char *) sendData, allSize);
	free(sendData);
	return 0;
}

int writeToMasterNextProc(Fes698TcpsMaster *m, const char *buf,
		const int length) {
	/** 打印收到服务端数据信息
	printTime();
	printf("recv master:");
	printHexCode((char *)buf, length);
	*/

	MasterMessage *recvData = (MasterMessage *)malloc(sizeof(MasterMessage));
	memset(recvData, 0, sizeof(MasterMessage));
	recvData->ctrl = buf[3]&0xFF;
	recvData->addressFmt = *(AddressFmt *)(buf+5);
	int fd = recvData->addressFmt.fd;
	Fes698TcpsClient   *c = getActiveClient(fd);
	//判断需要通讯的终端是否合法
	if ((c == NULL) || (getGatewayNum() != recvData->addressFmt.gatewayNum)
			|| ((c->remote.sin_addr.s_addr) != (recvData->addressFmt.ipv6d)
					|| (ntohs(c->remote.sin_port) != recvData->addressFmt.port))) {
		printTime();
		printf("invalid address:");
		printHexCode((char *)buf, length);
		writeToMasterExecFailMsg(m, recvData->addressFmt, NULL, 0);
		free(recvData);
		return 0;
	}
	if(recvData->ctrl == CTRL_SEND){
		writeDataToClient(getActiveClient(fd), (char *)(buf+MIN_MASTER_MSG_SIZE), length-MIN_MASTER_MSG_SIZE);

		/** 打印发送到终端数据信息
		printTime();
		printf("send client#%d:", fd);
		printHexCode((char *)(buf+MIN_MASTER_MSG_SIZE), length);
		*/
	} else if (recvData->ctrl == CTRL_CLOSE_DOMN){
		freeClient(c, CTRL_CLOSE_DOMN);
	} else if (recvData->ctrl == CTRL_CLOSE_BIND){ //bind master fd
		int bindIdx = *((unsigned char *)(buf+MIN_MASTER_MSG_SIZE));
		int masterIdx = (getMasterCount() - getBindMasterCount()) + bindIdx;
		if ((bindIdx > getBindMasterCount()) || (server.master[masterIdx] == NULL)
				|| (server.master[masterIdx]->bind < 1)) {
			printTime();
			printf("invalid bind address:");
			printHexCode((char *)buf, length);
			writeToMasterExecFailMsg(m, recvData->addressFmt, NULL, 0);
		} else {
			c->masterfd = server.master[masterIdx]->fd;
			c->bindtime = server.unixtime;
		}
	} else if (recvData->ctrl == CTRL_CLOSE_UNBIND){ //unbind master fd
		c->masterfd = 0;
	}
	free(recvData);
	return 0;
}
