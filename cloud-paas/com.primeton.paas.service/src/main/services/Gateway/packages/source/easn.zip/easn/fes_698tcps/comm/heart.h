#ifndef HEART_H_
#define HEART_H_

#include "tcps/fes_698tcps.h"
#include "util/util.h"

#define MAX_MSG_SIZE 1024
#define MSG_ERR	-1
#define MSG_NOREPOSE 2
#define MSG_OK	1

#define uchar unsigned char

#pragma pack(1)
typedef struct  heartdata
{
	char afn;
	char pnL;
	char pnH;
	char fnL;
	char fnH;
	char flag;
}heartData;

typedef struct  heartPackage
{
	uchar	beginChar1;
	uchar	len1L;
	uchar	len1H;
	uchar 	len2L;
	uchar	len2H;
	uchar	beginChar2;
	uchar	contrl;
	uchar 	divisionL;
	uchar	divisionH;
	uchar 	terminalL;
	uchar	terminalH;
	uchar	groupAdressFlag;
	uchar	afn;
	uchar	seq;
	uchar	pnL;
	uchar	pnH;
	uchar	FnL;
	uchar	FnH;
	char	reafn;
	char	repnL;
	char	repnH;
	char	refnL;
	char	refnH;
	char	reERR;
	uchar	cs;
	uchar	endchar;
}heartPackage;
#pragma pack()


int heartProcessFunc(Fes698TcpsClient *c, char *buff, int lenth);
#endif
