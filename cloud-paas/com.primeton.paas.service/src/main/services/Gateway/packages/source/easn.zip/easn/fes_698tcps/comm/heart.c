#include "heart.h"
#include <stdio.h>


/************************************************************************
 函数：发送心跳包


 ***************************************************************************/
int sendHeartMsg(Fes698TcpsClient *c, char *ptr, int length) {
//	printTime();
//	printf("......sendHeartMsg......\n");
	return writeDataToClient(c, ptr, length);
}


/************************************************************************
 函数：心跳包校验


 ***************************************************************************/

uchar heartMsgChk(heartPackage *ptr) {
	int index;
	uchar res = 0;
	char *pchar = (char *)&(ptr->contrl);

	for (index = 0; index < sizeof(heartPackage) - 8; index++) {
		res += pchar[index];
	}
	return res;
}

/************************************************************************
 函数：组装主站回复心跳包


 ***************************************************************************/
int packagingHeartMsg(heartPackage *desc, heartPackage *src) {
	int length = ((sizeof(heartPackage) - 8)<<2)|(src->len1L & 0x3);

	desc->beginChar1 = 0x68;
	desc->len1L = length & 0xFF;
	desc->len1H = (length >> 8) & 0xFF;
	desc->len2L = desc->len1L;
	desc->len2H = desc->len1H;
	desc->beginChar2 = desc->beginChar1;
	desc->contrl = 0x0B;

	desc->divisionL = src->divisionL;
	desc->divisionH = src->divisionH;
	desc->terminalL = src->terminalL;
	desc->terminalH = src->terminalH;
	desc->groupAdressFlag = src->groupAdressFlag;

	desc->afn = 0x00;
	desc->seq = src->seq & 0x6F;

	//信息点
	desc->pnL = 0x00;
	desc->pnH = 0x00;
	//信息类
	desc->FnL = 0x04;
	desc->FnH = 0x00;
	//回复报文afn
	desc->reafn = 0x02;
	//回复信息点
	desc->repnL = 0x00;
	desc->repnH = 0x00;
	//回复信息类
	desc->refnL = 0x04;
	desc->refnH = 0x00;
	//回复信息代码
	desc->reERR = 0x00;

	desc->cs = heartMsgChk(desc);
	desc->endchar = 0x16;
	return 1;
}

/************************************************************************
 函数：心跳包处理主函数

 return : -1报文有错误，0非心跳报文，1正确
 ***************************************************************************/
int heartProcessFunc(Fes698TcpsClient *c, char *buff, int lenth) {
	int res;
	heartPackage sendpkg, *recvpkg;

	recvpkg = (heartPackage*) buff;

	if ((recvpkg->afn != 0x02) || (recvpkg->FnH != 0) || (recvpkg->FnL != 0x04)
			|| ((recvpkg->contrl & 0x0f) != 0x09)) {
		return 0;//判断是心跳包，是否为可回复
	}
	if (lenth < 20) {
		return -1;
	}


	res = packagingHeartMsg(&sendpkg, recvpkg);
	if (res == 1) {
		sendHeartMsg(c ,(char *) &sendpkg, sizeof(heartPackage));
		return 1;
	}
	return res;
}
