#include "util.h"
static char stringTime[16] = { 0 };
void printTime() {
	time_t cur_time;
	struct tm *tmp_time;

	memset(stringTime, 0, sizeof(stringTime));
	time(&cur_time);
	tmp_time = localtime(&cur_time);

	sprintf(stringTime, "%02d%02d%02d %02d:%02d:%02d", tmp_time->tm_year % 100,
			tmp_time->tm_mon + 1, tmp_time->tm_mday, tmp_time->tm_hour,
			tmp_time->tm_min, tmp_time->tm_sec);
	printf("%s.%d@", stringTime, getpid());
}

static char *hexCode ="0123456789ABCDEF";
void printHexCode(char * data,int dataLength){
	int i;
	char *tmp;
	tmp = data;
	for(i=0;i<dataLength;i++){
		int ch=*tmp;
		putchar(hexCode[(ch>>4)&0xf]);
		putchar(hexCode[ch&0xf]);
		tmp++;
	}
	putchar('\n');
}
